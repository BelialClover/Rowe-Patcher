Go to this link for more updates
https://www.pokecommunity.com/showthread.php?t=442592

Link to the discord server
https://discord.gg/TEyFrcqE
Read this documents and the other ones before asking any question and read the rules on the server

Use http://onlinemd5.com to check the MD5 after patching 
to make sure you patched the game correctly
MD5 for 1.6.5.2 - 97857079F2C86A40BEB92FAE8A64BA32
Rom Used 
1986 Pokemon Emerald (U)( Trash Man)
MD5 - CFBFCF80C719B4EC40AF1823DCCEB030

-------------------------------------------------------------------------

Check that you are using one of the supported emulators
PC:                mGBA
Android:           MyBoy!
3DS:               Virtual Console Injection with NSUI
Vita and Switch:   mGBA standalone emulator
Other:             Retroarch mGBA core

Other emulators will crash so don't use them
Emulators that are known to crash a lot are
-John GBA
-No$gba
-VBA-M
-VBA GX
-gPSP
-Gbarunner2

-------------------------------------------------------------------------