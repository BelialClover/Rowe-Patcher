Go to this link for more updates
https://www.pokecommunity.com/showthread.php?t=442592

Go to this link to get the latest version
https://belialclover.github.io/Rowe-Patcher/

Link to the discord server
https://discord.gg/TEyFrcqE
Read this documents and the other ones before asking any question and read the rules on the server

Rom Used 
1986 Pokemon Emerald (U)( Trash Man)
MD5 - CFBFCF80C719B4EC40AF1823DCCEB030