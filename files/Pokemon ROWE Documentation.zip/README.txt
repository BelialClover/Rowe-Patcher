Go to this link for more updates
https://www.pokecommunity.com/showthread.php?t=442592

Go to this link to get the latest version
https://belialclover.github.io/Rowe-Patcher/

Link to the discord server
https://discord.gg/TEyFrcqE
Read this documents and the other ones before asking any question and read the rules on the server

Rom Used 
1986 Pokemon Emerald (U)( Trash Man)
MD5 - CFBFCF80C719B4EC40AF1823DCCEB030

Check that you are using one of the supported emulators
PC:                mGBA
Android:           MyBoy! and Pizzaboy GBA
3DS:               Virtual Console Injection with NSUI
Vita and Switch:   mGBA standalone emulator
IOS:               Retroarch mGBA core
Other:             Retroarch mGBA core

Other emulators will crash so don't use them
Emulators that are known to crash a lot are
-John GBA
-No$gba
-VBA-M
-VBA GX
-gPSP
-Gbarunner2
-Delta Emulator IOS

If you use another emulator, please don't report crashes, they will be ignored
and please see if you are using the latest version too