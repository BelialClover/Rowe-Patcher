Go to this link for more updates
https://www.pokecommunity.com/showthread.php?t=442592

Link to the discord server
https://discord.gg/TEyFrcqE
Read this documents and the other ones before asking any question and read the rules on the server

Use http://onlinemd5.com to check the MD5 after patching 
to make sure you patched the game correctly
MD5 for 1.6.8 - 
Rom Used 
1986 Pokemon Emerald (U)( Trash Man)
MD5 - CFBFCF80C719B4EC40AF1823DCCEB030